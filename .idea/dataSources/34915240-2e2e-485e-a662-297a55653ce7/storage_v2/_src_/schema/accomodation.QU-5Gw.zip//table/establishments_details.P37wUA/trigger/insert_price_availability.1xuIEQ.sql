create trigger insert_price_availability
  after INSERT
  on establishments_details
  for each row
BEGIN
insert into price_details(e_id) values(new.e_id);
insert into availability_details(e_id) values(new.e_id);
END;

