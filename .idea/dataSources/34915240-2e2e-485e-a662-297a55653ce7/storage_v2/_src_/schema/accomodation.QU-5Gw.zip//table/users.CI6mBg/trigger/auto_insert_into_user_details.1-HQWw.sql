create trigger auto_insert_into_user_details
  after INSERT
  on users
  for each row
begin
insert into user_details(id) values(new.id);
end;

