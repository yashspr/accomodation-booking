create trigger insert_establishment
  after UPDATE
  on user_details
  for each row
BEGIN
IF new.user_type = "owner" THEN
insert into establishments_details(owner_id) values(old.id);
END IF;
END;

